#include <stdio.h>
#include <string.h>

#define MAX 100

typedef struct {
    char op[3];
    char op1[3];
    char op2[3];
    char result[3];
} Quadruple;

int findCommonSubexpression(Quadruple quads[], int n, Quadruple *q) {
    for (int i = 0; i < n; i++) {
        if (strcmp(quads[i].op, q->op) == 0 && strcmp(quads[i].op1, q->op1) == 0 && strcmp(quads[i].op2, q->op2) == 0) {
            return i;
        }
    }
    return -1;
}

int main() {
    FILE *input = fopen("input.txt", "r");
    FILE *output = fopen("output.txt", "w");
    if (!input || !output) {
        printf("Error opening file.\n");
        return 1;
    }

    Quadruple quads[MAX], optimized[MAX];
    int n = 0, m = 0, t=0;
    char tnames[MAX][2][3];

    while (fscanf(input, "%s %s %s %s", quads[n].op, quads[n].op1, quads[n].op2, quads[n].result) != EOF) {
        n++;
    }

    for (int i = 0; i < n; i++) 
    {
    	  for(int j=0;j<t;j++)
        {	
		if( strcmp(quads[i].op1, tnames[j][0]) ==0 )
			strcpy( quads[i].op1, tnames[j][1] );
		
		if( strcmp(quads[i].op2, tnames[j][0]) ==0 )
			strcpy( quads[i].op2, tnames[j][1] );        	
        }
        	
        	
        int index = findCommonSubexpression(optimized, m, &quads[i]);
        if (index == -1) {
            optimized[m++] = quads[i];
        } else {
        	
        	strcpy( tnames[t][1], optimized[index].result );
        	strcpy( tnames[t][0], quads[i].result );
        	t++;
            
        }
    }


    fprintf(output, "Operator\tOp1\tOp2\tResult\n");
    for (int i = 0; i < m; i++) {
        fprintf(output, "%s\t\t%s\t%s\t%s\n", optimized[i].op, optimized[i].op1, optimized[i].op2, optimized[i].result);
    }

    fclose(input);
    fclose(output);

    printf("Optimization complete. Check output.txt for results.\n");
    return 0;
}


