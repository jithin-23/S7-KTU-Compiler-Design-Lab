#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int precedence(char c){
	if(c == '+' || c == '-'){
		return 1;
	}
	else if(c == '*' || c == '/'){
		return 2;
	}
	else if(c == '^'){
		return 3;
	}
	else{
		return 0;
	}
}

void postfix(char s[],char post[],char stack[], int top, int j){
	int n = strlen(s), i = 0;
	while(s[i] != '\0'){
		if(s[i] == '('){
			top++;
			stack[top] = s[i];
		}
		else if(isalpha(s[i])){
			post[j++] = s[i];
		}
		else if(precedence(s[i])){
			while(precedence(stack[top]) >= precedence(s[i])){
				post[j++] = stack[top--];
			}
			top++;
			stack[top] = s[i];
		}
		else if(s[i] == ')'){
			while(stack[top] != '('){
				post[j++] = stack[top--];
			}
			top--;
		}
		i++;
	}
	while(top!=-1){
		post[j++] = stack[top--];
	}
	post[j] = '\0';
}

void main(){
	
	char ind = '1';
	FILE *fp1;
	fp1 = fopen( "quadraple.txt","w");
	
	
	int i = 0;
	char s[100], post[100], stack[100], queue[100];
	int top = -1, j = 0, front = -1;
	
	printf("Input the string: ");
	scanf("%s", s);
	
	postfix(s,post,stack,top,j);
	
	printf("\nInfix : %s \nPostfix : %s\n\n\n", s, post);

	while(post[i] != '\0'){
		if(precedence(post[i])){
			char a = queue[front--];
			char b = queue[front--];
			if(isdigit(a) && isdigit(b)){

				fprintf(fp1,"%c\tt%c\tt%c\tt%c\n", post[i], b, a, ind);
			}
			else if(isdigit(b)){

				fprintf(fp1,"%c\tt%c\t%c\tt%c\n", post[i], b, a, ind);
			}
			else if(isdigit(a)){

				fprintf(fp1,"%c\t%c\tt%c\tt%c\n", post[i], b, a, ind);
			}
			else{

				fprintf(fp1,"%c\t%c\t%c\tt%c\n", post[i], b, a, ind);
			}

			front++;
			queue[front] = ind;
			ind++;
		}
		else{
			front++;
			queue[front] = post[i];
		}
		i++;
	
	}
}
